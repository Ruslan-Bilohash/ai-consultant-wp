                    GNU GENERAL PUBLIC LICENSE
                       Version 2, June 1991

 Copyright (C) 2025 Ruslan Bilohash
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

                            Preamble

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.

AI Consultant WP — це вільне програмне забезпечення.
Ви можете вільно використовувати, копіювати, поширювати та модифікувати його.

Цей плагін наразі знаходиться в тестовому режимі та розповсюджується безкоштовно.

Автор: Ruslan Bilohash
Сайт: https://bilohash.com
GitHub: https://github.com/ruslan-bilohash/ai-consultant-wp

---

                    GNU GENERAL PUBLIC LICENSE
                       Version 2, June 1991

 Copyright (C) 1989, 1991 Free Software Foundation, Inc.
 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.