<?php
/**
 * AI Consultant - Bot Handler
 * Version: 2.4.0
 */

if (!defined('ABSPATH')) {
    exit;
}

check_ajax_referer('ai_consultant_action', 'nonce');

$aicon_session = sanitize_text_field(wp_unslash($_POST['session'] ?? ''));
$aicon_message = trim(sanitize_text_field(wp_unslash($_POST['message'] ?? '')));

if (empty($aicon_message)) {
    wp_send_json_error(['message' => 'Порожнє повідомлення']);
    exit;
}

if (empty(AICON_XAI_API_KEY)) {
    wp_send_json_error(['message' => 'API ключ Grok не налаштовано. Перейдіть у налаштування плагіна → Grok API']);
    exit;
}

$aicon_file = AICON_CONVERSATIONS_DIR . '/' . sanitize_file_name($aicon_session) . '.json';

$aicon_conversation = file_exists($aicon_file)
    ? json_decode(file_get_contents($aicon_file), true) ?: []
    : [];

$aicon_settings = get_option('ai_consultant_settings', aicon_default_settings());

if (empty($aicon_conversation)) {
    $aicon_conversation[] = [
        'role'    => 'system',
        'content' => $aicon_settings['system_prompt'] ?? 'Ти професійний, дружній AI-консультант.'
    ];
}

$aicon_conversation[] = [
    'role'    => 'user',
    'content' => $aicon_message,
    'sender'  => 'client'
];

// Telegram client message
if (!empty($aicon_settings['enable_telegram']) && AICON_TELEGRAM_CHAT_ID > 0 && AICON_TELEGRAM_TOKEN) {
    $aicon_tg_client = "🟢 <b>Клієнт написав:</b>\n" . esc_html($aicon_message) 
                     . "\n\nSession: <code>" . esc_html($aicon_session) . "</code>";

    wp_remote_get("https://api.telegram.org/bot" . AICON_TELEGRAM_TOKEN . "/sendMessage?" . http_build_query([
        'chat_id'    => AICON_TELEGRAM_CHAT_ID,
        'text'       => $aicon_tg_client,
        'parse_mode' => 'HTML'
    ]));
}

// Prepare for Grok
$aicon_messages_for_api = [];
foreach ($aicon_conversation as $m) {
    if (!empty($m['content'])) {
        $aicon_messages_for_api[] = ['role' => $m['role'], 'content' => $m['content']];
    }
}

// Call Grok
$aicon_grok_response = wp_remote_post('https://api.x.ai/v1/chat/completions', [
    'headers' => [
        'Content-Type'  => 'application/json',
        'Authorization' => 'Bearer ' . trim(AICON_XAI_API_KEY),
    ],
    'body'    => wp_json_encode([
        'model'       => 'grok-4.20-0309-non-reasoning',
        'messages'    => $aicon_messages_for_api,
        'temperature' => 0.85,
        'max_tokens'  => 800,
    ]),
    'timeout' => 45,
]);

$aicon_reply = 'На жаль, проблема з підключенням до Grok API. Спробуйте пізніше.';

if (!is_wp_error($aicon_grok_response)) {
    $aicon_http_code = wp_remote_retrieve_response_code($aicon_grok_response);
    $aicon_body      = wp_remote_retrieve_body($aicon_grok_response);

    if ($aicon_http_code === 200) {
        $aicon_json = json_decode($aicon_body, true);
        $aicon_reply = $aicon_json['choices'][0]['message']['content'] ?? 'Вибачте, не вдалося сформувати відповідь.';
    } elseif ($aicon_http_code === 401) {
        $aicon_reply = 'Невірний API ключ Grok.';
    } elseif ($aicon_http_code === 400) {
        $aicon_reply = 'Grok API відхилив запит.';
    }
}

// Save bot reply
$aicon_conversation[] = [
    'role'    => 'assistant',
    'content' => $aicon_reply,
    'sender'  => 'bot'
];

// Telegram bot reply
if (!empty($aicon_settings['enable_telegram']) && AICON_TELEGRAM_CHAT_ID > 0 && AICON_TELEGRAM_TOKEN) {
    $aicon_tg_bot = "🧠 <b>Grok відповів:</b>\n" . esc_html($aicon_reply) 
                  . "\n\nSession: <code>" . esc_html($aicon_session) . "</code>";

    wp_remote_get("https://api.telegram.org/bot" . AICON_TELEGRAM_TOKEN . "/sendMessage?" . http_build_query([
        'chat_id'    => AICON_TELEGRAM_CHAT_ID,
        'text'       => $aicon_tg_bot,
        'parse_mode' => 'HTML'
    ]));
}

file_put_contents($aicon_file, json_encode($aicon_conversation, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

wp_send_json_success(['reply' => $aicon_reply]);