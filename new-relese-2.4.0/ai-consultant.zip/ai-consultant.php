<?php
/**
 * Plugin Name:       AI Consultant
 * Plugin URI:        https://github.com/Ruslan-Bilohash/ai-consultant-wp
 * Description:       Modern Grok (xAI) powered chatbot for WordPress with real-time Telegram notifications. Fully customizable design.
 * Version:           2.4.0
 * Author:            Ruslan Bilohash
 * Author URI:        https://bilohash.com
 * Author Email:      email@bilohash.com
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ai-consultant
 * Domain Path:       /languages
 * Requires at least: 6.4
 * Tested up to:      6.9
 * Requires PHP:      7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('AICON_VERSION', '2.4.0');
define('AICON_PATH', plugin_dir_path(__FILE__));
define('AICON_URL',  plugin_dir_url(__FILE__));

// Include core files
require_once AICON_PATH . 'includes/config.php';
require_once AICON_PATH . 'includes/admin-settings.php';

// Default settings fallback
if (!function_exists('aicon_default_settings')) {
    function aicon_default_settings() {
        return [
            'enable_chat'       => true,
            'xai_api_key'       => '',
            'telegram_token'    => '',
            'telegram_chat_id'  => 0,
            'primary_color'     => '#00f5ff',
            'accent_color'      => '#0099ff',
            'header_gradient'   => 'linear-gradient(135deg, #00f5ff 0%, #0099ff 100%)',
            'chat_bg_color'     => '#0f0f2d',
            'bot_icon'          => '💻',
            'chat_title'        => 'AI Консультант',
            'chat_subtitle'     => 'Ваш професійний консультант',
            'position'          => 'right',
            'widget_color'      => '#00f5ff',
            'widget_opacity'    => 1.0,
            'auto_open'         => true,
            'auto_open_delay'   => 4000,
            'welcome_text'      => 'Hi! 💻 I\'m an AI consultant from bilohash.com..',
            'system_prompt'     => 'Ти — професійний, дружній AI-консультант компанії bilohash.com.',
            'enable_telegram'   => true,
            'rate_limit'        => 30,
        ];
    }
}

// Activation hook
function aicon_activate() {
    if (!get_option('ai_consultant_settings')) {
        add_option('ai_consultant_settings', aicon_default_settings());
    }

    $dirs = [AICON_PATH . 'conversations', AICON_PATH . 'logs'];
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }
    }
}
register_activation_hook(__FILE__, 'aicon_activate');

// Frontend assets
function aicon_enqueue_frontend_assets() {
    $settings = get_option('ai_consultant_settings', aicon_default_settings());

    if (empty($settings['enable_chat'])) {
        return;
    }

    wp_enqueue_script(
        'aicon-chat',
        AICON_URL . 'assets/chat.js',
        [],
        AICON_VERSION,
        true
    );

    wp_localize_script('aicon-chat', 'aiConsultant', [
        'ajax_url'        => admin_url('admin-ajax.php'),
        'nonce'           => wp_create_nonce('ai_consultant_action'),
        'primary_color'   => esc_attr($settings['primary_color']),
        'accent_color'    => esc_attr($settings['accent_color']),
        'header_gradient' => esc_attr($settings['header_gradient']),
        'chat_bg_color'   => esc_attr($settings['chat_bg_color']),
        'bot_icon'        => esc_html($settings['bot_icon']),
        'chat_title'      => esc_html($settings['chat_title']),
        'chat_subtitle'   => esc_html($settings['chat_subtitle']),
        'position'        => esc_attr($settings['position']),
        'widget_color'    => esc_attr($settings['widget_color']),
        'widget_opacity'  => (float) $settings['widget_opacity'],
        'auto_open'       => (bool) $settings['auto_open'],
        'auto_open_delay' => (int) ($settings['auto_open_delay'] ?? 4000),
        'welcome_text'    => wp_kses_post($settings['welcome_text']),
        'is_rtl'          => is_rtl(),
    ]);
}
add_action('wp_enqueue_scripts', 'aicon_enqueue_frontend_assets');

// AJAX handlers
function aicon_bot_handler() {
    require_once AICON_PATH . 'includes/bot.php';
}
add_action('wp_ajax_ai_consultant_bot', 'aicon_bot_handler');
add_action('wp_ajax_nopriv_ai_consultant_bot', 'aicon_bot_handler');

// Admin menu з гарною іконкою
function aicon_admin_menu() {
    add_menu_page(
        'AI Consultant',
        'AI Consultant',
        'manage_options',
        'ai-consultant',
        'aicon_settings_page',
        'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiNmZmYiIHN0cm9rZS13aWR0aD0iMiI+PHBhdGggc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBkPSJNMTIgMkM2LjQ4IDIgMiA2LjQ4IDIgMTJzNC40OCAxMCAxMCAxMCAxMC00LjQ4IDEwLTEwUzE3LjUyIDIgMTIgMnoiLz48Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIzIi8+PC9zdmc+', 
        58
    );
}
add_action('admin_menu', 'aicon_admin_menu');

// Plugin action links
function aicon_action_links($links) {
    $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=ai-consultant')) . '"><strong>Налаштування</strong></a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'aicon_action_links');