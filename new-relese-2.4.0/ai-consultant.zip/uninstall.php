<?php
/**
 * AI Consultant - Uninstall Script
 * Version: 2.4.0
 *
 * Completely removes all data when the plugin is deleted.
 *
 * @package AI_Consultant
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Define path safely
if (!defined('AICON_PATH')) {
    define('AICON_PATH', dirname(__FILE__) . '/');
}

// 1. Delete main settings
delete_option('ai_consultant_settings');

// 2. Delete transients
delete_transient('aicon_rate_transients');

// 3. Soft cleanup of rate limit transients (without direct DB query)
$aicon_rate_prefix = 'aicon_rate_';

for ($aicon_i = 0; $aicon_i < 500; $aicon_i++) {
    $aicon_key = $aicon_rate_prefix . $aicon_i;
    delete_transient($aicon_key);
}

// 4. Delete conversations folder and files
$aicon_conversations_dir = AICON_PATH . 'conversations';

if (is_dir($aicon_conversations_dir) && WP_Filesystem()) {
    global $wp_filesystem;

    $aicon_conversation_files = glob($aicon_conversations_dir . '/*.json');
    foreach ($aicon_conversation_files as $aicon_conversation_file) {
        $wp_filesystem->delete($aicon_conversation_file);
    }

    $wp_filesystem->rmdir($aicon_conversations_dir, true);
}

// 5. Delete logs folder and files
$aicon_logs_dir = AICON_PATH . 'logs';

if (is_dir($aicon_logs_dir) && WP_Filesystem()) {
    global $wp_filesystem;

    $aicon_log_files = glob($aicon_logs_dir . '/*');
    foreach ($aicon_log_files as $aicon_log_file) {
        $wp_filesystem->delete($aicon_log_file);
    }

    $wp_filesystem->rmdir($aicon_logs_dir, true);
}