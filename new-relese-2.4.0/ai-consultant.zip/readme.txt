=== AI Consultant ===
Contributors: rbilohash
Donate link: https://bilohash.com/donate.php
Tags: ai, chatbot, grok, telegram, artificial-intelligence
Requires at least: 6.4
Tested up to: 6.9
Stable tag: 2.4.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI Consultant is a modern Grok (xAI) powered chatbot for WordPress with real-time Telegram notifications and full design customization.

== Description ==

AI Consultant is a beautiful and intelligent AI chatbot for WordPress built with Grok from xAI.

It allows you to:
- Connect Grok xAI as your smart assistant
- Receive all customer messages instantly in Telegram
- Fully customize the chat design (colors, gradients, icons, position)
- Automatically save conversation history

Perfect for cleaning services, consulting businesses, repair services, and any company that needs fast and smart customer support.

**Key Features:**
- Powered by Grok xAI
- Real-time Telegram notifications (client + bot replies)
- Fully responsive and customizable design
- Live settings preview
- Conversation history saving

== Installation ==

1. Upload the plugin to the `/wp-content/plugins/ai-consultant/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **AI Consultant → Settings**
4. Enter your Grok xAI API Key
5. Configure Telegram notifications (optional)
6. Save settings and test the chat on your website

== Frequently Asked Questions ==

= Do I need an API key? =
Yes. The plugin requires a Grok xAI API key to work. Without it, the chatbot cannot generate responses.

= How do I get a Grok API key? =
Go to https://console.x.ai/, log in with your X (Twitter) account, and create a new API key.

= Does it send notifications to Telegram? =
Yes. When enabled, all customer messages and bot replies are sent to your Telegram in real time.

= Can I customize the chat appearance? =
Yes. You can change colors, gradients, position, icon, and more from the settings page with live preview.

== External Services ==

This plugin uses the following external services:

1. **Grok xAI API** – https://api.x.ai/
   - Used to generate intelligent chatbot responses
   - Requires an API key from https://console.x.ai/

2. **Telegram Bot API** – https://api.telegram.org/
   - Used to send real-time notifications to the site administrator

== Changelog ==

= 2.4.0 =
* Fixed all Plugin Check issues
* Improved security and code standards
* Updated admin interface and instructions
* Better prefix standardization
* Code optimization

= 2.3.4 =
* Initial release

== Upgrade Notice ==

= 2.4.0 =
Please update to version 2.4.0 for full compatibility with current WordPress standards and Plugin Check requirements.