<?php
/**
 * AI Consultant - Get Conversation History
 * Version: 2.4.0
 *
 * @package AI_Consultant
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

header('Content-Type: application/json; charset=utf-8');

// Security check - nonce verification
if (!isset($_GET['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['nonce'])), 'ai_consultant_action')) {
    http_response_code(403);
    echo json_encode(['error' => 'Security check failed']);
    exit;
}

$aicon_session = isset($_GET['session']) 
    ? sanitize_text_field(wp_unslash($_GET['session'])) 
    : '';

if (empty($aicon_session) || !preg_match('/^s_\d+_[a-z0-9]{6,16}$/i', $aicon_session)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid session format']);
    exit;
}

$aicon_file = AICON_CONVERSATIONS_DIR . '/' . sanitize_file_name($aicon_session) . '.json';

if (!file_exists($aicon_file)) {
    echo json_encode([]);
    exit;
}

$aicon_raw_data = json_decode(file_get_contents($aicon_file), true) ?: [];
$aicon_output   = [];

foreach ($aicon_raw_data as $aicon_row) {
    if (!empty($aicon_row['content']) && in_array($aicon_row['sender'] ?? '', ['client', 'bot'], true)) {
        $aicon_output[] = [
            'sender'  => $aicon_row['sender'],
            'content' => $aicon_row['content']
        ];
    }
}

echo json_encode($aicon_output, JSON_UNESCAPED_UNICODE);