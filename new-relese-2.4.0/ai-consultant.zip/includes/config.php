<?php
/**
 * AI Consultant — Configuration File
 * Version: 2.4.0
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('AICON_PATH')) {
    define('AICON_PATH', plugin_dir_path(dirname(__FILE__)));
}

if (!defined('AICON_URL')) {
    define('AICON_URL', plugin_dir_url(dirname(__FILE__)));
}

// Default settings fallback
if (!function_exists('aicon_default_settings')) {
    function aicon_default_settings() {
        return [
            'enable_chat'         => true,
            'xai_api_key'         => '',
            'telegram_token'      => '',
            'telegram_chat_id'    => 0,
            'primary_color'       => '#00f5ff',
            'accent_color'        => '#0099ff',
            'header_gradient'     => 'linear-gradient(135deg, #00f5ff 0%, #0099ff 100%)',
            'chat_bg_color'       => '#0f0f2d',
            'bot_icon'            => '🧹',
            'chat_title'          => 'AI Consultant',
            'chat_subtitle'       => 'Profesionalus valymo konsultantas',
            'position'            => 'right',
            'widget_color'        => '#00f5ff',
            'widget_opacity'      => 1.0,
            'auto_open'           => true,
            'auto_open_delay'     => 4000,
            'welcome_text'        => "Sveiki! 🧹 Aš esu AI konsultantas із bilohash.com/ai/wordpress.",
            'system_prompt'       => "Ти — професійний, дружній AI-консультант компанії bilohash.com.",
            'enable_telegram'     => true,
            'rate_limit'          => 30,
        ];
    }
}

// Load settings
$aicon_settings = get_option('ai_consultant_settings', aicon_default_settings());

// Important constants
define('AICON_XAI_API_KEY', $aicon_settings['xai_api_key'] ?? '');
define('AICON_TELEGRAM_TOKEN', $aicon_settings['telegram_token'] ?? '');
define('AICON_TELEGRAM_CHAT_ID', (int) ($aicon_settings['telegram_chat_id'] ?? 0));

define('AICON_CONVERSATIONS_DIR', AICON_PATH . 'conversations');
define('AICON_LOGS_DIR', AICON_PATH . 'logs');

// Create folders
if (!is_dir(AICON_CONVERSATIONS_DIR)) {
    wp_mkdir_p(AICON_CONVERSATIONS_DIR);
}
if (!is_dir(AICON_LOGS_DIR)) {
    wp_mkdir_p(AICON_LOGS_DIR);
}