<?php
/**
 * AI Consultant GROK - Settings Page
 * Version: 2.5.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Consultant GROK Settings Page
 */
function aicon_grok_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Недостатньо прав для доступу.', 'ai-consultant-grok'));
    }

    // Save settings
    if (isset($_POST['ai_consultant_grok_save'])) {
        check_admin_referer('ai_consultant_grok_save_settings');

        $bot_icon = !empty($_POST['bot_icon_custom'])
            ? sanitize_text_field(wp_unslash($_POST['bot_icon_custom']))
            : sanitize_text_field(wp_unslash($_POST['bot_icon'] ?? '🧹'));

        $new_settings = [
            'enable_chat'        => !empty($_POST['enable_chat']),
            'xai_api_key'        => sanitize_text_field(wp_unslash($_POST['xai_api_key'] ?? '')),
            'telegram_token'     => sanitize_text_field(wp_unslash($_POST['telegram_token'] ?? '')),
            'telegram_chat_id'   => (int) sanitize_text_field(wp_unslash($_POST['telegram_chat_id'] ?? 0)),
            'primary_color'      => sanitize_hex_color(wp_unslash($_POST['primary_color'] ?? '#00f5ff')),
            'accent_color'       => sanitize_hex_color(wp_unslash($_POST['accent_color'] ?? '#0099ff')),
            'header_gradient'    => sanitize_text_field(wp_unslash($_POST['header_gradient'] ?? 'linear-gradient(135deg, #00f5ff 0%, #0099ff 100%)')),
            'chat_bg_color'      => sanitize_hex_color(wp_unslash($_POST['chat_bg_color'] ?? '#0f0f2d')),
            'bot_icon'           => $bot_icon,
            'chat_title'         => sanitize_text_field(wp_unslash($_POST['chat_title'] ?? 'AI Consultant GROK')),
            'chat_subtitle'      => sanitize_text_field(wp_unslash($_POST['chat_subtitle'] ?? 'Profesionalus valymo konsultantas')),
            'position'           => in_array($_POST['position'] ?? 'right', ['left', 'right'], true) 
                                    ? sanitize_text_field(wp_unslash($_POST['position'])) 
                                    : 'right',
            'widget_color'       => sanitize_hex_color(wp_unslash($_POST['widget_color'] ?? '#00f5ff')),
            'widget_opacity'     => min(1.0, max(0.1, floatval(sanitize_text_field(wp_unslash($_POST['widget_opacity'] ?? 1.0))))),
            'auto_open'          => !empty($_POST['auto_open']),
            'auto_open_delay'    => absint(sanitize_text_field(wp_unslash($_POST['auto_open_delay'] ?? 4000))),
            'welcome_text'       => wp_kses_post(wp_unslash($_POST['welcome_text'] ?? '')),
            'system_prompt'      => wp_kses_post(wp_unslash($_POST['system_prompt'] ?? '')),
            'enable_telegram'    => !empty($_POST['enable_telegram'])
        ];

        update_option('ai_consultant_grok_settings', $new_settings);

        echo '<div class="notice notice-success is-dismissible">
                <p style="color:#000000 !important; margin:0; font-size:15px;">
                    <strong>✅ Налаштування успішно збережено!</strong>
                </p>
              </div>';
    }

    $settings = get_option('ai_consultant_grok_settings', aicon_grok_default_settings());
    $current_version = AICON_GROK_VERSION;
    ?>

    <div class="wrap ai-consultant-grok-settings">

        <div class="ai-consultant-grok-header">
            <div class="header-left">
                <span class="dashicons dashicons-broom ai-logo-icon"></span>
                <div>
                    <h1>AI Consultant GROK</h1>
                    <p class="version-info">Версія <?php echo esc_html($current_version); ?> для WordPress 6.9+</p>
                </div>
            </div>
           
            <div class="header-right">
                <a href="https://github.com/Ruslan-Bilohash/ai-consultant-wp" 
                   target="_blank" 
                   class="header-btn">
                    <span>🐙</span> GitHub
                </a>
                <a href="https://bilohash.com/ai/wordpress" 
                   target="_blank" 
                   class="header-btn">
                    <span>🌐</span> Сайт плагіну
                </a>
                <a href="https://bilohash.com/donate.php" 
                   target="_blank" 
                   class="pro-btn">
                    <span>❤️</span> Підтримати
                </a>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field('ai_consultant_grok_save_settings'); ?>

            <h2 class="nav-tab-wrapper">
                <a href="#" class="nav-tab nav-tab-active" data-tab="general">🛠 Загальні</a>
                <a href="#" class="nav-tab" data-tab="prompt">📝 Інструкція для бота</a>
                <a href="#" class="nav-tab" data-tab="design">🎨 Дизайн чату</a>
                <a href="#" class="nav-tab" data-tab="widget">📱 Плаваючий віджет</a>
                <a href="#" class="nav-tab" data-tab="grok">🧠 Grok API</a>
                <a href="#" class="nav-tab" data-tab="telegram">📲 Telegram</a>
            </h2>

            <!-- Tab: General -->
            <div id="tab-general" class="tab-content">
                <table class="form-table">
                    <tr>
                        <th scope="row">🟢 Увімкнути чатбот</th>
                        <td><input type="checkbox" name="enable_chat" <?php checked($settings['enable_chat'] ?? true); ?>></td>
                    </tr>
                    <tr>
                        <th scope="row">📌 Заголовок чату</th>
                        <td><input type="text" name="chat_title" value="<?php echo esc_attr($settings['chat_title'] ?? 'AI Consultant GROK'); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row">📌 Підзаголовок чату</th>
                        <td><input type="text" name="chat_subtitle" value="<?php echo esc_attr($settings['chat_subtitle'] ?? 'Profesionalus valymo konsultantas'); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row">🤖 Іконка бота</th>
    <td>
        <select name="bot_icon" style="font-size:28px; width:380px; padding:8px;">
            <!-- 🎯 Загальні AI / Роботи -->
            <option value="🤖" <?php selected($settings['bot_icon'] ?? '🤖', '🤖'); ?>>🤖 Робот (класичний)</option>
            <option value="🦾" <?php selected($settings['bot_icon'] ?? '🤖', '🦾'); ?>>🦾 Кібер-робот</option>
            <option value="🧠" <?php selected($settings['bot_icon'] ?? '🤖', '🧠'); ?>>🧠 Штучний інтелект</option>
            <option value="💡" <?php selected($settings['bot_icon'] ?? '🤖', '💡'); ?>>💡 Ідея / Геній</option>
            
            <!-- 🚀 Сучасні та технологічні -->
            <option value="🚀" <?php selected($settings['bot_icon'] ?? '🤖', '🚀'); ?>>🚀 Ракета</option>
            <option value="⚡" <?php selected($settings['bot_icon'] ?? '🤖', '⚡'); ?>>⚡ Блискавка</option>
            <option value="🔥" <?php selected($settings['bot_icon'] ?? '🤖', '🔥'); ?>>🔥 Вогонь</option>
            <option value="🌟" <?php selected($settings['bot_icon'] ?? '🤖', '🌟'); ?>>🌟 Зірка</option>
            <option value="✨" <?php selected($settings['bot_icon'] ?? '🤖', '✨'); ?>>✨ Блиск</option>
            
            <!-- 💼 Бізнес / Консультації -->
            <option value="💼" <?php selected($settings['bot_icon'] ?? '🤖', '💼'); ?>>💼 Кейс / Бізнес</option>
            <option value="📊" <?php selected($settings['bot_icon'] ?? '🤖', '📊'); ?>>📊 Аналітика</option>
            <option value="📈" <?php selected($settings['bot_icon'] ?? '🤖', '📈'); ?>>📈 Зростання</option>
            
            <!-- 🏠 Побут / Послуги -->
            <option value="🧹" <?php selected($settings['bot_icon'] ?? '🤖', '🧹'); ?>>🧹 Мітла</option>
            <option value="🧼" <?php selected($settings['bot_icon'] ?? '🤖', '🧼'); ?>>🧼 Мило</option>
            <option value="🧽" <?php selected($settings['bot_icon'] ?? '🤖', '🧽'); ?>>🧽 Губка</option>
            <option value="🏠" <?php selected($settings['bot_icon'] ?? '🤖', '🏠'); ?>>🏠 Будинок</option>
            <option value="🛠️" <?php selected($settings['bot_icon'] ?? '🤖', '🛠️'); ?>>🛠️ Ремонт</option>
            
            <!-- 👥 Люди / Підтримка -->
            <option value="👨‍💼" <?php selected($settings['bot_icon'] ?? '🤖', '👨‍💼'); ?>>👨‍💼 Консультант</option>
            <option value="👩‍💼" <?php selected($settings['bot_icon'] ?? '🤖', '👩‍💼'); ?>>👩‍💼 Консультантка</option>
            <option value="🙋" <?php selected($settings['bot_icon'] ?? '🤖', '🙋'); ?>>🙋 Підтримка</option>
            
            <!-- 🌐 Інше -->
            <option value="🌐" <?php selected($settings['bot_icon'] ?? '🤖', '🌐'); ?>>🌐 Глобальна мережа</option>
            <option value="📱" <?php selected($settings['bot_icon'] ?? '🤖', '📱'); ?>>📱 Смартфон</option>
            <option value="💻" <?php selected($settings['bot_icon'] ?? '🤖', '💻'); ?>>💻 Комп'ютер</option>
            <option value="📧" <?php selected($settings['bot_icon'] ?? '🤖', '📧'); ?>>📧 Конверт</option>
            <option value="🔮" <?php selected($settings['bot_icon'] ?? '🤖', '🔮'); ?>>🔮 Магія / Майбутнє</option>
        </select>
        <p class="description">Оберіть готову іконку або вставте будь-який інший емодзі нижче.</p>
        <input type="text" name="bot_icon_custom" value="<?php echo esc_attr($settings['bot_icon'] ?? '🤖'); ?>"
               placeholder="Вставте свій емодзі (наприклад: 🚀 або 🦾)" 
               style="width:380px; font-size:32px; margin-top:10px; padding:8px;">
    </td>
</tr>
                </table>
            </div>

            <!-- Tab: Prompt -->
            <div id="tab-prompt" class="tab-content" style="display:none;">
                <table class="form-table">
                    <tr>
                        <th scope="row">👋 Привітальне повідомлення</th>
                        <td>
                            <textarea name="welcome_text" rows="6" style="width:100%;"><?php echo esc_textarea($settings['welcome_text'] ?? ''); ?></textarea>
                            <p class="description">Перше повідомлення, яке бот покаже клієнту.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">🧠 Системний промпт</th>
                        <td>
                            <textarea name="system_prompt" rows="24" style="width:100%; font-family:monospace; font-size:13.5px; line-height:1.6;"><?php echo esc_textarea($settings['system_prompt'] ?? ''); ?></textarea>
                            <p class="description"><strong>Найважливіше поле!</strong> Опис поведінки бота.</p>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Tab: Design -->
            <div id="tab-design" class="tab-content" style="display:none;">
                <h3>🎨 Дизайн чату</h3>
                <p style="margin-bottom:25px;color:#555;">Зміни видно відразу в живому попередньому перегляді.</p>

                <table class="form-table aicon-color-table">
                    <tr>
                        <th scope="row">🎨 Основний колір<br><small>(повідомлення клієнта)</small></th>
                        <td>
                            <div class="color-picker-group">
                                <input type="color" name="primary_color" id="primary_color" value="<?php echo esc_attr($settings['primary_color'] ?? '#00f5ff'); ?>">
                                <span id="primary_color_value" class="color-value"><?php echo esc_html($settings['primary_color'] ?? '#00f5ff'); ?></span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">🎨 Акцентний колір</th>
                        <td>
                            <div class="color-picker-group">
                                <input type="color" name="accent_color" id="accent_color" value="<?php echo esc_attr($settings['accent_color'] ?? '#0099ff'); ?>">
                                <span id="accent_color_value" class="color-value"><?php echo esc_html($settings['accent_color'] ?? '#0099ff'); ?></span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">🌈 Градієнт заголовка</th>
                        <td>
                            <div class="color-picker-group">
                                <input type="color" name="header_gradient" id="header_gradient" value="<?php echo esc_attr($settings['header_gradient'] ?? '#00f5ff'); ?>">
                                <span id="header_gradient_value" class="color-value"><?php echo esc_html($settings['header_gradient'] ?? 'linear-gradient(...)'); ?></span>
                            </div>
                            <p class="description">Основний колір градієнта</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">🖼 Колір фону чату</th>
                        <td>
                            <div class="color-picker-group">
                                <input type="color" name="chat_bg_color" id="chat_bg_color" value="<?php echo esc_attr($settings['chat_bg_color'] ?? '#0f0f2d'); ?>">
                                <span id="chat_bg_color_value" class="color-value"><?php echo esc_html($settings['chat_bg_color'] ?? '#0f0f2d'); ?></span>
                            </div>
                        </td>
                    </tr>
                </table>

                <!-- Live Preview -->
                <div style="margin-top:35px;padding:25px;background:#f8f9fa;border-radius:16px;">
                    <h4 style="margin-bottom:15px;">🔴 Живий попередній перегляд</h4>
                    <div id="design-preview" style="max-width:420px;margin:0 auto;background:#0a0f24;border-radius:20px;overflow:hidden;box-shadow:0 20px 60px rgba(0,245,255,0.35);">
                        <div id="preview-header" style="background:<?php echo esc_attr($settings['header_gradient'] ?? 'linear-gradient(135deg, #00f5ff 0%, #0099ff 100%)'); ?>;padding:18px 20px;color:#000;font-weight:600;display:flex;align-items:center;gap:14px;">
                            <span style="font-size:32px;"><?php echo esc_html($settings['bot_icon'] ?? '🧹'); ?></span>
                            <div>
                                <div><?php echo esc_html($settings['chat_title'] ?? 'AI Consultant GROK'); ?></div>
                                <div style="font-size:13.5px;opacity:0.95;"><?php echo esc_html($settings['chat_subtitle'] ?? 'Profesionalus valymo konsultantas'); ?></div>
                            </div>
                        </div>
                        <div id="preview-body" style="height:260px;padding:20px;background:<?php echo esc_attr($settings['chat_bg_color'] ?? '#0f0f2d'); ?>;overflow-y:auto;display:flex;flex-direction:column;gap:14px;">
                            <div style="max-width:75%;background:#1e2a4a;padding:14px 18px;border-radius:16px 16px 16px 4px;align-self:flex-start;color:#fff;">
                                Привіт! Як я можу допомогти з прибиранням?
                            </div>
                            <div id="preview-client-msg" style="max-width:75%;background:<?php echo esc_attr($settings['primary_color'] ?? '#00f5ff'); ?>;color:#000;padding:14px 18px;border-radius:16px 16px 4px 16px;align-self:flex-end;">
                                Скільки коштує генеральне прибирання квартири?
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tab: Widget -->
            <div id="tab-widget" class="tab-content" style="display:none;">
                <table class="form-table">
                    <tr>
                        <th scope="row">📍 Позиція плаваючої кнопки</th>
                        <td>
                            <select name="position">
                                <option value="right" <?php selected($settings['position'] ?? 'right', 'right'); ?>>Праворуч</option>
                                <option value="left" <?php selected($settings['position'] ?? 'right', 'left'); ?>>Ліворуч</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">⏱ Авто-відкриття чату</th>
                        <td><input type="checkbox" name="auto_open" <?php checked($settings['auto_open'] ?? true); ?>></td>
                    </tr>
                    <tr>
                        <th scope="row">⏱ Затримка авто-відкриття (мс)</th>
                        <td>
                            <input type="number" name="auto_open_delay" value="<?php echo esc_attr($settings['auto_open_delay'] ?? 4000); ?>" step="500">
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Tab: Grok API -->
            <div id="tab-grok" class="tab-content" style="display:none;">
                <h3>🧠 Grok xAI API</h3>
                <p style="margin-bottom:20px;">Для роботи чатбота потрібен API ключ від xAI (Grok).</p>

                <table class="form-table">
                    <tr>
                        <th scope="row">🔑 Grok xAI API Key</th>
                        <td>
                            <input type="text" name="xai_api_key" id="xai_api_key" 
                                   value="<?php echo esc_attr($settings['xai_api_key'] ?? ''); ?>" 
                                   class="regular-text" style="width:100%; font-family:monospace;">
                            <p class="description">
                                <strong>Як отримати ключ:</strong><br>
                                1. Перейдіть на <a href="https://console.x.ai/" target="_blank">https://console.x.ai/</a><br>
                                2. Увійдіть через акаунт X (Twitter)<br>
                                3. Натисніть "Create new API key"<br>
                                4. Скопіюйте ключ і вставте сюди
                            </p>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Tab: Telegram -->
            <div id="tab-telegram" class="tab-content" style="display:none;">
                <h3>📲 Сповіщення в Telegram</h3>
                <p style="margin-bottom:20px;">Плагін може надсилати всі повідомлення клієнтів вам у Telegram.</p>

                <table class="form-table">
                    <tr>
                        <th scope="row">🤖 Telegram Bot Token</th>
                        <td>
                            <input type="text" name="telegram_token" id="telegram_token" 
                                   value="<?php echo esc_attr($settings['telegram_token'] ?? ''); ?>" 
                                   class="regular-text" style="width:100%; font-family:monospace;">
                            <p class="description">
                                <strong>Як створити бота:</strong><br>
                                1. Відкрийте Telegram → @BotFather<br>
                                2. Напишіть /newbot<br>
                                3. Скопіюйте токен і вставте сюди
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">👤 Ваш Telegram Chat ID</th>
                        <td>
                            <input type="text" name="telegram_chat_id" id="telegram_chat_id" 
                                   value="<?php echo esc_attr($settings['telegram_chat_id'] ?? ''); ?>" 
                                   class="regular-text">
                            <p class="description">
                                <strong>Як отримати Chat ID:</strong><br>
                                Напишіть боту будь-яке повідомлення, потім відкрийте:<br>
                                <a href="https://api.telegram.org/bot[ТОКЕН]/getUpdates" target="_blank">https://api.telegram.org/bot[ТОКЕН]/getUpdates</a>
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">📨 Увімкнути сповіщення</th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_telegram" <?php checked($settings['enable_telegram'] ?? true); ?>>
                                Надсилати всі повідомлення клієнтів мені в Telegram
                            </label>
                        </td>
                    </tr>
                </table>
            </div>

            <p class="submit">
                <input type="submit" name="ai_consultant_grok_save" class="button button-primary button-large save-btn" value="💾 Зберегти всі налаштування">
            </p>
        </form>
    </div>

    <?php
    wp_register_style('aicon-grok-admin', AICON_GROK_URL . 'assets/admin.css', [], AICON_GROK_VERSION);
    wp_enqueue_style('aicon-grok-admin');
    ?>

    <script>
    // Tab switching
    document.querySelectorAll('.nav-tab').forEach(function(tab) {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('nav-tab-active'));
            this.classList.add('nav-tab-active');
            document.querySelectorAll('.tab-content').forEach(c => c.style.display = 'none');
            document.getElementById('tab-' + this.dataset.tab).style.display = 'block';
        });
    });

    // Live preview
    document.addEventListener('DOMContentLoaded', function() {
        const primaryInput = document.getElementById('primary_color');
        const headerInput  = document.getElementById('header_gradient');
        const bgInput      = document.getElementById('chat_bg_color');

        const previewClient = document.getElementById('preview-client-msg');
        const previewHeader = document.getElementById('preview-header');
        const previewBody   = document.getElementById('preview-body');

        const primaryValue = document.getElementById('primary_color_value');
        const headerValue  = document.getElementById('header_gradient_value');
        const bgValue      = document.getElementById('chat_bg_color_value');

        function updatePreview() {
            if (previewClient) previewClient.style.background = primaryInput.value;
            if (previewHeader) previewHeader.style.background = headerInput.value;
            if (previewBody)   previewBody.style.background   = bgInput.value;

            if (primaryValue) primaryValue.textContent = primaryInput.value;
            if (headerValue)  headerValue.textContent  = headerInput.value;
            if (bgValue)      bgValue.textContent      = bgInput.value;
        }

        if (primaryInput) primaryInput.addEventListener('input', updatePreview);
        if (headerInput)  headerInput.addEventListener('input', updatePreview);
        if (bgInput)      bgInput.addEventListener('input', updatePreview);

        updatePreview();
    });
    </script>
    <?php
}